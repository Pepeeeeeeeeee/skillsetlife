<template>
    <h1 class="title" id="faq">FAQ</h1>
    <div class="faq-container">

        <div class="questions">
            <div class="question left">
                <h3>Lorem ipsum dolor sit amet</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                    Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                    Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
                    Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                </p>
            </div>

            <div class="question right">
                <h3>Lorem ipsum dolor sit amet</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                    Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                    Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
                    Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                </p>
            </div>

            <div class="question left">
                <h3>Lorem ipsum dolor sit amet</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                    Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                    Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
                    Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                </p>
            </div>

            <div class="question right">
                <h3>Lorem ipsum dolor sit amet</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                    Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                    Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
                    Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                </p>
            </div>

            <div class="question left">
                <h3>Lorem ipsum dolor sit amet</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                    Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                    Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
                    Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                </p>
            </div>
        </div>
    </div>
</template>

<script>
export default ({
	name: "FooterPage",
	components: {
},
	data() {
		return {}
	},
    methods: {
    }
})
</script>

<style scoped>
    h3 {
    padding: .6em;
    text-align: center;
    font-size: 16px;
    background-color: #2395e7;
    color: white;
    }

    p {
        max-width: 615px;
        width: 90%;
        font-size: 14px;
        margin: 0 1.5em;
    }

@media screen and (min-width: 800px) {
    p {
        font-size: 16px;
    }

    .question {
        margin-bottom: 3em;
    }

    .question.left {
        margin-right: 25%;
    }
   .question.left h3 {
        text-align: right;
        padding-right: 2.5em;
        border-radius: 0 8px 8px 0;
    }
    .question.left p {
        margin-left: auto;
    }
    .question.right {
        margin-left: 25%;
    }
    .question.right h3 {
        text-align: left;
        padding-left: 2.5em;
        border-radius: 8px 0 0 8px;
    }
}

@media screen and (min-width: 1280px) {
    .question.left {
        margin-right: 40%;
    }
    .question.right {
        margin-left: 40%;
    }
}

    /* .faq-container {
        width: 100%;
    }


    .questions {
    margin-top: 3em;
    display: block;
    }

    .question {
    height: -webkit-fit-content;
    height: -moz-fit-content;
    height: fit-content;
    margin-bottom: 4em;
    }

    h3 {
    border-radius: 1px;
    padding: .6em;
    text-align: center;
    font-size: 16px;
    background-color: #2395e7;
    }

    p {
    font-size: 14px;
    max-width: 615px;
    margin: 0 auto;
    width: 90%;
    }

    .questions {
    margin-top: 3em;
    display: block;
    }

    .question {
    height: -webkit-fit-content;
    height: -moz-fit-content;
    height: fit-content;
    font-size: 16px;
    margin-bottom: 4em;
    }



    p {
        max-width: 615px;
        width: 90%;
        font-size: 16px;
        margin: 0 1.5em;
    }

    h3 {
        padding: .6em;
        background-color: #2395e7;
        color: white;
        font-size: 18px;
    }
    .question.left {
        margin-right: 25%;
    }
   .question.left h3 {
        text-align: right;
        padding-right: 2.5em;
        border-radius: 0 8px 8px 0;
    }
    .question.left p {
        margin-left: auto;
    }
    .question.right {
        margin-left: 25%;
    }
    .question.right h3 {
        text-align: left;
        padding-left: 2.5em;
        border-radius: 8px 0 0 8px;
    } */

</style>